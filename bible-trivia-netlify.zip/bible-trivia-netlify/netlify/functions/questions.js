exports.handler = async function (event, context) {
  // Only allow POST
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { category, difficulty } = JSON.parse(event.body);

    const prompt = `Generate 7 Christian Bible trivia questions for the category "${category}" at "${difficulty}" difficulty level.

Return ONLY valid JSON (no markdown, no backticks) in this exact format:
{"questions":[{"question":"...","options":["A) ...","B) ...","C) ...","D) ..."],"answer":0,"explanation":"Brief explanation referencing Bible verses."}]}

Rules:
- "answer" is 0-based index of correct option
- Exactly 4 options per question
- Biblically accurate and educational
- ${difficulty === "Easy" ? "Use well-known stories and basic facts" : difficulty === "Medium" ? "Include moderately specific details and characters" : "Use deep knowledge, specific verses, genealogies, and nuanced theology"}
- Category focus: ${category}`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 2000,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await response.json();
    const text = data.content.map((b) => b.text || "").join("");
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(parsed),
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to generate questions." }),
    };
  }
};
