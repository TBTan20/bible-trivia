# ✝ Bible Trivia — PWA with Netlify Functions

Your API key is kept **100% private** using Netlify Functions as a secure backend.

## File Structure
```
bible-trivia-netlify/
├── index.html                     ← Main app
├── manifest.json                  ← PWA config
├── netlify.toml                   ← Netlify config
├── sw.js                          ← Service worker
├── icons/
│   ├── icon-192.png
│   └── icon-512.png
└── netlify/
    └── functions/
        └── questions.js           ← Secure API function
```

## Deploy Steps

### Step 1: Upload to GitHub
1. Go to your existing GitHub repo (or create a new one)
2. Upload ALL files and folders from this zip, maintaining the folder structure
3. Make sure `netlify/functions/questions.js` is in the right place

### Step 2: Connect to Netlify
1. Go to app.netlify.com
2. Click "Add new site" → "Import from Git"
3. Select your GitHub repo
4. Click "Deploy site"

### Step 3: Add your API key (the secure way!)
1. In Netlify, go to your site → **Site configuration** → **Environment variables**
2. Click **"Add a variable"**
3. Key: `ANTHROPIC_API_KEY`
4. Value: your API key from https://console.anthropic.com/settings/keys
5. Click **Save**
6. Go to **Deploys** → **Trigger deploy** → **Deploy site**

That's it! Your API key lives only in Netlify's secure environment — never in your code.

## How It Works
- User picks a category → browser calls `/.netlify/functions/questions`
- Netlify Function (server-side) uses the secret API key to call Anthropic
- Questions are returned to the browser
- API key is never visible to anyone

## Adding to iPhone Home Screen
1. Open the site in Safari on iPhone
2. Tap the Share button
3. Tap "Add to Home Screen"
4. Tap "Add" — appears like a native app!
