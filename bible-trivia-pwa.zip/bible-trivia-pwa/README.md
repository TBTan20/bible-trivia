# ✝ Bible Trivia — PWA

A Progressive Web App for Christian Bible trivia, powered by Claude AI.

## Files
```
bible-trivia-pwa/
├── index.html       ← Main app (all HTML, CSS, JS)
├── manifest.json    ← PWA metadata
├── sw.js            ← Service worker (offline support)
└── icons/
    ├── icon-192.png
    └── icon-512.png
```

## How to Deploy (Free Options)

### Option 1: Netlify (Easiest — drag & drop)
1. Go to https://netlify.com and sign up free
2. Drag the entire `bible-trivia-pwa` folder onto the Netlify dashboard
3. Done! You'll get a URL like `https://your-app.netlify.app`

### Option 2: GitHub Pages
1. Create a free GitHub account at https://github.com
2. Create a new repository
3. Upload all files in this folder
4. Go to Settings → Pages → Deploy from branch (main)
5. Your site will be live at `https://yourusername.github.io/repo-name`

### Option 3: Vercel
1. Go to https://vercel.com
2. Connect your GitHub repo or drag & drop the folder
3. Instant deployment with a free URL

## ⚠️ Important: Add Your API Key
The app calls the Anthropic API to generate questions. Before deploying:

1. Open `index.html`
2. Find this line in the `fetchQuestions` function:
   ```
   headers: { "Content-Type": "application/json" },
   ```
3. Add your API key:
   ```
   headers: { 
     "Content-Type": "application/json",
     "x-api-key": "YOUR_API_KEY_HERE",
     "anthropic-version": "2023-06-01",
     "anthropic-dangerous-direct-browser-access": "true"
   },
   ```
4. Get your API key at: https://console.anthropic.com

## Adding to iPhone Home Screen
Once deployed, users can:
1. Open the site in Safari on iPhone
2. Tap the Share button (box with arrow)
3. Scroll down and tap "Add to Home Screen"
4. Tap "Add" — it appears like a native app!

## Features
- 5 Bible categories (Old Testament, New Testament, Psalms & Proverbs, Apostles & Disciples, Miracles)
- 3 difficulty levels (Easy, Medium, Hard)
- AI-generated questions with explanations
- Streak tracking
- Star rating system
- Offline support via Service Worker
- Install prompt for Android
- Safe area support for iPhone notches
